package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
    public static Employees getEmployees() {
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(1, "Alice", "Smith", "alice@example.com", "Software Engineer"));
        list.add(new Employee(2, "Bob", "Johnson", "bob@example.com", "Product Manager"));
        list.add(new Employee(3, "Charlie", "Williams", "charlie@example.com", "QA Engineer"));
        list.add(new Employee(4, "Diana", "Brown", "diana@example.com", "UX Designer"));
        return new Employees(list);
    }
}
